package id.fusionmusic.player;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(12, 13, 17);
    private final int surface = Color.rgb(25, 27, 34);
    private final int muted = Color.rgb(164, 168, 181);
    private final int white = Color.WHITE;
    private final int pink = Color.rgb(255, 63, 99);
    private final int green = Color.rgb(30, 215, 96);
    private MediaPlayer player;
    private Uri selectedAudio;
    private TextView status;
    private TextView nowPlayingTitle;
    private Button playButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(20), dp(20), dp(20));
        scroll.addView(content);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout brandBlock = new LinearLayout(this);
        brandBlock.setOrientation(LinearLayout.VERTICAL);
        TextView brand = text("FUSION", 13, pink, true);
        TextView title = text("Good evening", 27, white, true);
        brandBlock.addView(brand);
        brandBlock.addView(title);
        top.addView(brandBlock, new LinearLayout.LayoutParams(0, -2, 1));

        TextView avatar = text("♪", 23, white, true);
        avatar.setGravity(Gravity.CENTER);
        avatar.setBackground(round(pink, 100));
        top.addView(avatar, new LinearLayout.LayoutParams(dp(48), dp(48)));
        content.addView(top);

        LinearLayout search = new LinearLayout(this);
        search.setGravity(Gravity.CENTER_VERTICAL);
        search.setPadding(dp(15), 0, dp(15), 0);
        search.setBackground(round(surface, 18));
        TextView magnify = text("⌕", 27, muted, false);
        search.addView(magnify);
        TextView searchLabel = text("Artists, songs, albums", 14, muted, false);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, dp(52));
        slp.leftMargin = dp(10);
        search.addView(searchLabel, slp);
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, dp(52));
        searchParams.topMargin = dp(22);
        content.addView(search, searchParams);

        section(content, "Made for your mood", "YOUR MIX");
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        hero.setBackground(gradient(pink, Color.rgb(104, 45, 150), 24));
        TextView eyebrow = text("FUSION MIX  •  01", 11, Color.WHITE, true);
        TextView heroTitle = text("Your sound.\nYour world.", 29, white, true);
        TextView heroDesc = text("Bring your music services together.", 13, Color.WHITE, false);
        Button explore = button("Explore music  ↗", white, Color.rgb(45, 25, 60));
        explore.setOnClickListener(v -> openUrl("https://music.apple.com/"));
        LinearLayout.LayoutParams htp = new LinearLayout.LayoutParams(-1, -2);
        htp.topMargin = dp(9);
        hero.addView(eyebrow);
        hero.addView(heroTitle, htp);
        LinearLayout.LayoutParams hdp = new LinearLayout.LayoutParams(-1, -2);
        hdp.topMargin = dp(5);
        hero.addView(heroDesc, hdp);
        LinearLayout.LayoutParams hep = new LinearLayout.LayoutParams(-2, dp(43));
        hep.topMargin = dp(17);
        hero.addView(explore, hep);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(15);
        content.addView(hero, hp);

        section(content, "Jump back in", "RECENTS");
        HorizontalScrollView recentScroll = new HorizontalScrollView(this);
        recentScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout recentRow = new LinearLayout(this);
        recentRow.setOrientation(LinearLayout.HORIZONTAL);
        recentRow.addView(albumCard("♫", "Local library", "Your files", pink, () -> chooseAudio()));
        recentRow.addView(albumCard("♫", "Apple Music", "Listen now", Color.rgb(224, 55, 86), () -> openUrl("https://music.apple.com/")));
        recentRow.addView(albumCard("●", "Spotify", "Open Spotify", green, () -> openUrl("https://open.spotify.com/")));
        recentScroll.addView(recentRow);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(150));
        rp.topMargin = dp(10);
        content.addView(recentScroll, rp);

        section(content, "Choose your source", "CONNECT");
        LinearLayout services = new LinearLayout(this);
        services.setOrientation(LinearLayout.VERTICAL);
        services.addView(serviceRow("", "Apple Music", "Open your Apple Music library", pink,
            () -> openUrl("https://music.apple.com/")));
        services.addView(serviceRow("●", "Spotify", "Open playlists and podcasts", green,
            () -> openUrl("https://open.spotify.com/")));
        services.addView(serviceRow("♫", "Offline library", "Play audio stored on this phone", Color.rgb(100, 130, 255),
            () -> chooseAudio()));
        LinearLayout.LayoutParams svp = new LinearLayout.LayoutParams(-1, -2);
        svp.topMargin = dp(8);
        content.addView(services, svp);

        LinearLayout localPanel = new LinearLayout(this);
        localPanel.setOrientation(LinearLayout.VERTICAL);
        localPanel.setPadding(dp(15), dp(14), dp(15), dp(14));
        localPanel.setBackground(round(surface, 18));
        TextView localTitle = text("NOW PLAYING", 10, muted, true);
        nowPlayingTitle = text("Nothing playing yet", 14, white, true);
        status = text("Choose a local audio file to play offline.", 12, muted, false);
        playButton = button("Choose audio file", pink, white);
        playButton.setOnClickListener(v -> {
            if (selectedAudio == null) chooseAudio();
            else togglePlayback();
        });
        localPanel.addView(localTitle);
        LinearLayout.LayoutParams ntp = new LinearLayout.LayoutParams(-1, -2);
        ntp.topMargin = dp(5);
        localPanel.addView(nowPlayingTitle, ntp);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2);
        stp.topMargin = dp(4);
        localPanel.addView(status, stp);
        LinearLayout.LayoutParams pbp = new LinearLayout.LayoutParams(-1, dp(44));
        pbp.topMargin = dp(12);
        localPanel.addView(playButton, pbp);
        LinearLayout.LayoutParams lpp = new LinearLayout.LayoutParams(-1, -2);
        lpp.topMargin = dp(18);
        content.addView(localPanel, lpp);

        TextView disclaimer = text("Streaming playback and official downloads stay in each service app. Local files can play offline here.", 11, muted, false);
        disclaimer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.topMargin = dp(17);
        dp.bottomMargin = dp(8);
        content.addView(disclaimer, dp);

        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(bottomNav());
        setContentView(root);
    }

    private void section(LinearLayout parent, String title, String kicker) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(22), 0, 0);
        TextView t = text(title, 19, white, true);
        row.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(text(kicker, 10, muted, true));
        parent.addView(row);
    }

    private View albumCard(String symbol, String name, String sub, int color, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(9));
        card.setBackground(round(surface, 16));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(138), -1);
        cp.rightMargin = dp(10);
        TextView art = text(symbol, 30, white, true);
        art.setGravity(Gravity.CENTER);
        art.setBackground(gradient(color, darken(color), 13));
        card.addView(art, new LinearLayout.LayoutParams(-1, dp(78)));
        TextView nameView = text(name, 13, white, true);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = dp(7);
        card.addView(nameView, np);
        TextView subView = text(sub, 11, muted, false);
        card.addView(subView);
        card.setOnClickListener(v -> action.run());
        return wrapView(card, cp);
    }

    private View wrapView(View v, LinearLayout.LayoutParams p) {
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.addView(v, p);
        return wrapper;
    }

    private View serviceRow(String symbol, String name, String desc, int color, Runnable action) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackground(round(surface, 16));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(72));
        rp.bottomMargin = dp(8);

        TextView icon = text(symbol, 22, white, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(round(color, 14));
        row.addView(icon, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setPadding(dp(12), 0, dp(4), 0);
        labels.addView(text(name, 14, white, true));
        labels.addView(text(desc, 11, muted, false));
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(text("›", 25, muted, false));
        row.setOnClickListener(v -> action.run());
        return wrapView(row, rp);
    }

    private View bottomNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(8), dp(9), dp(8), dp(9));
        nav.setBackgroundColor(Color.rgb(17, 18, 23));
        String[][] items = {{"⌂", "Home"}, {"⌕", "Search"}, {"♫", "Library"}};
        for (int i = 0; i < items.length; i++) {
            final int index = i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            TextView symbol = text(items[i][0], 21, i == 0 ? pink : muted, true);
            TextView label = text(items[i][1], 10, i == 0 ? white : muted, false);
            item.addView(symbol);
            item.addView(label);
            item.setOnClickListener(v -> {
                if (index == 1) openUrl("https://open.spotify.com/search");
                if (index == 2) chooseAudio();
            });
            nav.addView(item, new LinearLayout.LayoutParams(0, dp(48), 1));
        }
        return nav;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button button(String label, int color, int textColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTextColor(textColor);
        b.setAllCaps(false);
        b.setBackgroundTintList(ColorStateList.valueOf(color));
        return b;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private GradientDrawable gradient(int a, int b, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{a, b});
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int darken(int c) {
        return Color.rgb((int)(Color.red(c)*0.55), (int)(Color.green(c)*0.55), (int)(Color.blue(c)*0.55));
    }

    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No compatible app or browser found.", Toast.LENGTH_SHORT).show();
        }
    }

    private void chooseAudio() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        try {
            startActivityForResult(i, 410);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "File picker unavailable.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 410 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedAudio = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(selectedAudio, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (SecurityException ignored) { }
            releasePlayer();
            nowPlayingTitle.setText(selectedAudio.getLastPathSegment() == null ? "Selected audio file" : selectedAudio.getLastPathSegment());
            status.setText("Ready for offline playback.");
            playButton.setText("Play selected file");
            playButton.setOnClickListener(v -> togglePlayback());
        }
    }

    private void togglePlayback() {
        if (selectedAudio == null) { chooseAudio(); return; }
        if (player != null && player.isPlaying()) {
            player.pause();
            playButton.setText("Resume playback");
            status.setText("Paused");
            return;
        }
        if (player != null) {
            player.start();
            playButton.setText("Pause playback");
            status.setText("Playing local audio offline");
            return;
        }
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(this, selectedAudio);
            player.setOnPreparedListener(mp -> {
                mp.start();
                playButton.setText("Pause playback");
                status.setText("Playing local audio offline");
            });
            player.setOnCompletionListener(mp -> {
                playButton.setText("Play selected file");
                status.setText("Playback finished");
                releasePlayer();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                status.setText("This audio format could not be played.");
                releasePlayer();
                return true;
            });
            status.setText("Loading audio…");
            player.prepareAsync();
        } catch (IOException | IllegalStateException e) {
            status.setText("Unable to open this audio file.");
            releasePlayer();
        }
    }

    private void releasePlayer() {
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (IllegalStateException ignored) { }
            player.release();
            player = null;
        }
    }

    @Override protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }
}
