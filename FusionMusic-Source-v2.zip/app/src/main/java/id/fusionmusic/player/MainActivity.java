package id.fusionmusic.player;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(13, 14, 18);
    private final int panel = Color.rgb(27, 29, 36);
    private final int red = Color.rgb(250, 65, 90);
    private final int green = Color.rgb(30, 215, 96);
    private MediaPlayer player;
    private TextView status;
    private Button playButton;
    private Uri selectedAudio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(24));
        page.setBackgroundColor(bg);

        TextView logo = new TextView(this);
        logo.setText("fusion music");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(30);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(logo);

        TextView subtitle = new TextView(this);
        subtitle.setText("Your music, one place.");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(15);
        LinearLayout.LayoutParams subParams = params(-1, -2);
        subParams.bottomMargin = dp(24);
        page.addView(subtitle, subParams);

        TextView servicesTitle = sectionTitle("STREAMING SERVICES");
        page.addView(servicesTitle);

        Button apple = makeButton("Open Apple Music", red);
        page.addView(apple, buttonParams());
        apple.setOnClickListener(v -> openUrl("https://music.apple.com/"));

        Button spotify = makeButton("Open Spotify", green);
        page.addView(spotify, buttonParams());
        spotify.setTextColor(Color.BLACK);
        spotify.setOnClickListener(v -> openUrl("https://open.spotify.com/"));

        TextView localTitle = sectionTitle("OFFLINE LIBRARY");
        LinearLayout.LayoutParams titleParams = params(-1, -2);
        titleParams.topMargin = dp(26);
        page.addView(localTitle, titleParams);

        TextView description = new TextView(this);
        description.setText("Play audio files stored on your phone. Local playback works without internet. Official streaming downloads stay inside their own apps.");
        description.setTextColor(Color.rgb(195, 198, 208));
        description.setTextSize(14);
        description.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams descParams = params(-1, -2);
        descParams.bottomMargin = dp(14);
        page.addView(description, descParams);

        Button choose = makeButton("Choose local audio file", panel);
        page.addView(choose, buttonParams());
        choose.setOnClickListener(v -> chooseAudio());

        playButton = makeButton("Play selected file", panel);
        page.addView(playButton, buttonParams());
        playButton.setEnabled(false);
        playButton.setOnClickListener(v -> togglePlayback());

        Button stop = makeButton("Stop playback", panel);
        page.addView(stop, buttonParams());
        stop.setOnClickListener(v -> stopPlayback());

        status = new TextView(this);
        status.setText("Ready. Choose a local audio file to begin.");
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(13);
        LinearLayout.LayoutParams statusParams = params(-1, -2);
        statusParams.topMargin = dp(14);
        page.addView(status, statusParams);

        TextView footer = new TextView(this);
        footer.setText("Fusion Music • Prototype 0.1.0");
        footer.setTextColor(Color.GRAY);
        footer.setTextSize(11);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerParams = params(-1, -2);
        footerParams.topMargin = dp(28);
        page.addView(footer, footerParams);

        setContentView(page);
    }

    private TextView sectionTitle(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.rgb(180, 183, 194));
        view.setTextSize(12);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button makeButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(15);
        button.setTextColor(Color.WHITE);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        return button;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = params(-1, dp(52));
        p.topMargin = dp(9);
        return p;
    }

    private LinearLayout.LayoutParams params(int width, int height) {
        return new LinearLayout.LayoutParams(width, height);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void openUrl(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No compatible browser or app found.", Toast.LENGTH_SHORT).show();
        }
    }

    private void chooseAudio() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        try {
            startActivityForResult(intent, 410);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "File picker is not available.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 410 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedAudio = data.getData();
            getContentResolver().takePersistableUriPermission(
                selectedAudio, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            releasePlayer();
            playButton.setEnabled(true);
            status.setText("Selected: " + selectedAudio.getLastPathSegment());
        }
    }

    private void togglePlayback() {
        if (selectedAudio == null) {
            Toast.makeText(this, "Choose an audio file first.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (player != null && player.isPlaying()) {
            player.pause();
            playButton.setText("Resume playback");
            status.setText("Paused");
            return;
        }
        if (player != null) {
            player.start();
            playButton.setText("Pause playback");
            status.setText("Playing local audio");
            return;
        }
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build());
            player.setDataSource(this, selectedAudio);
            player.setOnPreparedListener(mp -> {
                mp.start();
                playButton.setText("Pause playback");
                status.setText("Playing local audio");
            });
            player.setOnCompletionListener(mp -> {
                playButton.setText("Play selected file");
                status.setText("Playback finished");
                releasePlayer();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                status.setText("Could not play this file. Try MP3, WAV, or a supported format.");
                releasePlayer();
                return true;
            });
            status.setText("Loading audio…");
            player.prepareAsync();
        } catch (IOException | IllegalStateException e) {
            status.setText("Unable to open this audio file.");
            releasePlayer();
        }
    }

    private void stopPlayback() {
        releasePlayer();
        playButton.setText("Play selected file");
        status.setText(selectedAudio == null
            ? "Ready. Choose a local audio file to begin."
            : "Stopped. Selected file is ready.");
    }

    private void releasePlayer() {
        if (player != null) {
            try {
                if (player.isPlaying()) player.stop();
            } catch (IllegalStateException ignored) { }
            player.release();
            player = null;
        }
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }
}
