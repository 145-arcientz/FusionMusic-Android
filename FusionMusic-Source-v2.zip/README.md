# Fusion Music (Android prototype)

Fusion Music is a lightweight Android companion prototype with a combined Apple Music / Spotify-inspired look.

## Features in this starter
- Buttons to open Apple Music and Spotify.
- Local audio file picker and basic play/pause/stop using Android `MediaPlayer`.
- Local file playback works offline after the file is stored on the phone.
- GitHub Actions workflow builds a debug APK automatically.

## Important service limitations
This prototype does **not** sign in to Apple Music or Spotify, and does not combine their protected audio streams into one player.
- Apple Music catalog access requires a properly configured MusicKit/API integration, developer token, user authorization, and any required subscription.
- Spotify integration should use Spotify's approved Android App Remote / Web API flow and its developer policies.
- Official offline downloads remain inside the official service apps. This app cannot import, decrypt, or replay their protected downloads.
- The local player handles audio files the user can access on their device; exact codec support depends on Android/device support.

## Build with GitHub Actions
1. Create a GitHub repository and upload all files in this project.
2. Push to the `main` branch, or open **Actions → Build Fusion Music APK → Run workflow**.
3. Wait for the workflow to finish.
4. Open the successful run, download the `fusion-music-debug-apk` artifact, and extract `app-debug.apk`.
5. Install the APK on the Realme 5 Pro. You may need to allow installation from your browser/file manager.

## Build locally
Requires JDK 17, Android SDK, and Gradle 8.9:
```bash
gradle assembleDebug
```

## Next steps for production
- Add OAuth/authorization and a secure backend for Apple Music developer tokens.
- Register a Spotify app and configure package name, signing fingerprint, redirect URI, and Client ID.
- Add a proper now-playing screen, metadata artwork, queue, media session, and audio focus handling.
- Do not commit private keys, signing passwords, or long-lived secrets into the repository.
